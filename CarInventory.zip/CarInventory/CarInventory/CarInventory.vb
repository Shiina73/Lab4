﻿Option Strict On

' Author Name: Mike Cusson
' Project: Car Inventory
' Date: 07-12-2019
' Description: This is the sickest car inventory thing evar. Super busy this week so comments are a no show unfortunately...

Public Class frmCarInventory
    Private carList As New SortedList
    Private currentCarIdentification As String = String.Empty
    Private formEdit As Boolean = False

    Private Function IsValidInput() As Boolean

        Dim returnValue As Boolean = True
        Dim outputMesssage As String = String.Empty

        If cmbMake.SelectedIndex = -1 Then
            outputMesssage += "Please be sure to select your cars make uwu...    "
            returnValue = False
        End If

        If cmbYear.SelectedIndex = -1 Then
            outputMesssage += "Don't forget your cars year uwu...    "
            returnValue = False
        End If

        If txtModel.Text.Trim.Length = 0 Then
            outputMesssage += "How could you forget your cars model uwu...?   "
            returnValue = False
        End If
        Try
            If txtPrice.Text.Trim.Length = 0 Or CInt(txtPrice.Text) <= 0 Or IsNumeric(CInt(txtPrice.Text)) = False Then
                outputMesssage += "We need to know how much the car is uwu... Make sure it's above zero too...    "
                returnValue = False

            End If
        Catch
            outputMesssage += "Please ensure that your price is a number uwu...    "
            returnValue = False
        End Try
        lblResult.Text = outputMesssage
        Return returnValue

    End Function
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        carList = New SortedList
        txtModel.Text = String.Empty
        txtPrice.Text = String.Empty
        lvwCar.Items.Clear()
        lblResult.Text = ""

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim car As Cars
        Dim carItem As ListViewItem

        If IsValidInput() = True Then
            formEdit = True


            If currentCarIdentification.Trim.Length = 0 Then
                car = New Cars(cmbMake.Text, cmbYear.Text, txtModel.Text, txtPrice.Text, cbNew.Checked)
                carList.Add(car.IdentificationNumber.ToString(), car)
            Else
                car = CType(carList.Item(currentCarIdentification), Cars)

                car.Make = cmbMake.Text
                car.Model = txtModel.Text
                car.Price = txtPrice.Text
                car.Year = cmbYear.Text
                car.newCar = cbNew.Checked
            End If

            lvwCar.Items.Clear()

            For Each carEntry As DictionaryEntry In carList
                carItem = New ListViewItem()
                car = CType(carEntry.Value, Cars)

                carItem.Checked = car.newCar
                carItem.SubItems.Add(car.IdentificationNumber.ToString())
                carItem.SubItems.Add(car.Make)
                carItem.SubItems.Add(car.Model)
                carItem.SubItems.Add(car.Year)
                carItem.SubItems.Add(car.Price)

                lvwCar.Items.Add(carItem)

            Next carEntry
            Reset()
            formEdit = False

        End If

    End Sub

    Private Sub lvwCars_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwCar.SelectedIndexChanged

        Const identificationSubItemIndex As Integer = 1

        currentCarIdentification = lvwCar.Items(lvwCar.FocusedItem.Index).SubItems(identificationSubItemIndex).Text

        Dim car As Cars = CType(carList.Item(currentCarIdentification), Cars)
        cmbMake.Text = car.Make
        txtModel.Text = car.Model
        cmbYear.Text = car.Year
        txtPrice.Text = car.Price
        cbNew.Checked = car.newCar

        lblResult.Text = car.GetCarInfo()


    End Sub
    Private Sub Reset()
        cmbMake.SelectedIndex = -1
        txtModel.Text = String.Empty
        cmbYear.SelectedIndex = -1
        txtPrice.Text = String.Empty
        cbNew.Checked = False

    End Sub

    Private Sub lvwCar_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles lvwCar.ItemCheck
        If formEdit = False Then
            e.NewValue = e.CurrentValue
        End If
    End Sub
End Class



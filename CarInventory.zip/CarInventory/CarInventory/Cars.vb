﻿Option Strict On

'this code was taken from the sample and edited.

' Author Name: Mike Cusson
' Project: Cars
' Date: 07-12-2019
' Description: This is also the sickest car inventory thing evar. Super busy this week so comments are a no show unfortunately...

Public Class Cars

    Private Shared increment As Integer
    Private carIdentificationNumber As Integer = 0
    Private carMake As String = String.Empty
    Private carModel As String = String.Empty
    Private carYear As String = String.Empty
    Private carPrice As String = String.Empty
    Private carNew As Boolean = False

    Public Sub New()

        increment += 1
        carIdentificationNumber = increment

    End Sub

    Public Sub New(Make As String, Model As String, Year As String, Price As String, newCar As Boolean)

        Me.New()

        carMake = Make
        carModel = Model
        carPrice = Price
        carNew = newCar
        carYear = Year


    End Sub

    Public ReadOnly Property Count() As Integer
        Get
            Return increment
        End Get
    End Property
    Public ReadOnly Property IdentificationNumber() As Integer
        Get
            Return carIdentificationNumber
        End Get
    End Property

    Public Property newCar() As Boolean
        Get
            Return carNew
        End Get
        Set(value As Boolean)
            carNew = value
        End Set
    End Property
    Public Property Make() As String
        Get
            Return carMake
        End Get
        Set(value As String)
            carMake = value
        End Set
    End Property
    Public Property Model() As String
        Get
            Return carModel
        End Get
        Set(value As String)
            carModel = value
        End Set
    End Property
    Public Property Year() As String
        Get
            Return carYear
        End Get
        Set(value As String)
            carYear = value
        End Set
    End Property
    Public Property Price As String
        Get
            Return carPrice
        End Get
        Set(value As String)
            carPrice = value
        End Set
    End Property

    Public Function GetCarInfo() As String

        Return "The car you inserted was a " & carMake & "  " & carModel & " That was made in " & carYear & ". The car can be purchesed for $" & carPrice & ". " & IIf(carNew = True, "This car is brand new!", "this car is not new").ToString()

    End Function

End Class